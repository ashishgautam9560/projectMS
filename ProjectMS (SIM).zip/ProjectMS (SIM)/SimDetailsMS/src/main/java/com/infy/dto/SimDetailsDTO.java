package com.infy.dto;

import javax.validation.constraints.Pattern;

import com.infy.entity.SimDetails;

public class SimDetailsDTO 
{
	private int simId ;
	@Pattern(regexp = "[0-9]{10}", message = "Invalid Service Number..!!")
	private String serviceNumber ;
	@Pattern(regexp = "[0-9]{13}", message = "Invalid Sim Number..!!s")
	private String simNumber ;
	private String simStatus ;
	public SimDetailsDTO() 
	{
		super();
	}

	@Override
	public String toString() 
	{
		return "SimDetailsDTO [simId=" + simId + ", serviceNumber=" + serviceNumber + ", simNumber=" + simNumber
		+ ", simStatus=" + simStatus + "]";
	}

	public int getSimId() {
		return simId;
	}
	public void setSimId(int simId) {
		this.simId = simId;
	}
	public String getServiceNumber() {
		return serviceNumber;
	}
	public void setServiceNumber(String serviceNumber) {
		this.serviceNumber = serviceNumber;
	}
	public String getSimNumber() {
		return simNumber;
	}
	public void setSimNumber(String simNumber) {
		this.simNumber = simNumber;
	}
	public String getSimStatus() {
		return simStatus;
	}
	public void setSimStatus(String simStatus) {
		this.simStatus = simStatus;
	}
	
	public static SimDetails prepareSimDetailsEntity(SimDetailsDTO objSimdDetailsDTO)
	{
		SimDetails objSimDetails = new SimDetails();
		
		objSimDetails.setServiceNumber(objSimdDetailsDTO.getServiceNumber());
		objSimDetails.setSimId(objSimdDetailsDTO.getSimId());
		objSimDetails.setSimNumber(objSimdDetailsDTO.getSimNumber());
		objSimDetails.setSimStatus(objSimdDetailsDTO.getSimStatus());
		
		return objSimDetails;
	}
}










