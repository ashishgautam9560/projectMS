package com.infy.controller;


import java.util.stream.Collectors;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infy.advice.Message;
import com.infy.dto.SimDetailsDTO;
import com.infy.dto.SimOffersDTO;
import com.infy.exception.DetailsNotFoundException;
import com.infy.service.SimService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@CrossOrigin
@Validated
public class SimController 
{
	@Autowired 
	SimService simService;
	
	@Autowired
	RestTemplate template;
	
	
	@GetMapping(value = "/getsimdetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public SimDetailsDTO getSimDetails(@RequestParam("simId") int simId)
	{
		return simService.getSimDetails(simId);
	}
	
	@HystrixCommand(fallbackMethod = "simDetailsFallBack")
	@PostMapping(value = "/validate")
	public String simValidation(@Valid @RequestBody SimDetailsDTO objSimDetailsDTO, Errors errors) throws DetailsNotFoundException
	{
		String response = "";
		if(errors.hasErrors())
		{
			response = errors.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(","));
			Message message = new Message();
			message.setStatusCode(HttpStatus.NOT_ACCEPTABLE.value());
			message.setMessages(response);
			
			return "Invalid details..!!";
		}
		else 
		{
			SimDetailsDTO status = simService.simStatus(objSimDetailsDTO.getSimNumber());
			if(status == null)
				return "Invalid details..!!";
			else {
				String status_n = status.getSimStatus();
				SimOffersDTO simOffersDTO = template.getForObject("http://SIMOFFERSMS" + "/simoffers/getsimoffers/" + status.getSimId(), SimOffersDTO.class);
				String offer = " Offer Details " + simOffersDTO.getOfferName()+" "+simOffersDTO.getCost()+" "+simOffersDTO.getCallQty()+" "+simOffersDTO.getDataQty()+" "+simOffersDTO.getDuration();
				status_n+=offer;
				return status_n;
			}
			
		}
	}
	
	
	public String simValidationFallback(@Valid @RequestBody SimDetailsDTO objSimDetailsDTO, Errors errors)
	{
		return "Inside the FALLBACK service";
	}
	
	@PostMapping(value = "/addsimdetails", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> addSimDetails(@RequestBody SimDetailsDTO objSimDetailsDTO)
	{
		simService.addSimDetails(objSimDetailsDTO);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
