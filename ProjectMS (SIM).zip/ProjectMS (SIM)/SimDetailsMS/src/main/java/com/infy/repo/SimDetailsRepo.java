package com.infy.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infy.entity.SimDetails;

@Repository
public interface SimDetailsRepo extends JpaRepository<SimDetails, Integer>
{
	public SimDetails findBySimNumber(String simNumber);
}
