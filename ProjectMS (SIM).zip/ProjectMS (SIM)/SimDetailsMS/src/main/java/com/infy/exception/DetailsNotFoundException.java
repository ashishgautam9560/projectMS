package com.infy.exception;

public class DetailsNotFoundException extends Exception
{
	// 1)
	private static final long serialVersionUID = 7280126124843070201L;

	// 2) default
	public DetailsNotFoundException() {}

	// 3) parameterized
	public DetailsNotFoundException(String str) 
	{
		super(str);
	}
}
