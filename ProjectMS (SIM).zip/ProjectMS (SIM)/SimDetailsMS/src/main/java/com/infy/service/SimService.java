package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.SimDetailsDTO;
import com.infy.entity.SimDetails;

import com.infy.repo.SimDetailsRepo;

@Service
public class SimService
{
	@Autowired
	SimDetailsRepo simDetailsRepo;
	
	public SimDetailsDTO simStatus(String simNumber) {
		SimDetails objSimDetails = simDetailsRepo.findBySimNumber(simNumber);
		SimDetailsDTO objSimDetailsDTO = SimDetails.createSimDetailsDTO(objSimDetails);
		return objSimDetailsDTO;
	}
	
	public SimDetailsDTO getSimDetails(int simId) {
		SimDetails objSimDetails = simDetailsRepo.getById(simId);
		SimDetailsDTO objSimDetailsDTO = SimDetails.createSimDetailsDTO(objSimDetails);
		return objSimDetailsDTO;
	}
	
	public void addSimDetails(SimDetailsDTO objSimDetailsDTO) {
		simDetailsRepo.saveAndFlush(SimDetailsDTO.prepareSimDetailsEntity(objSimDetailsDTO));
		
	}
}
