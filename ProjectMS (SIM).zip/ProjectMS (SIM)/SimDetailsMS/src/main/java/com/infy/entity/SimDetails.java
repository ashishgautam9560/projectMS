package com.infy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;

import com.infy.dto.SimDetailsDTO;
//import com.infy.dto.SimOffersDTO;

@Entity
public class SimDetails 
{
	@Column @Id
	private int simId ;
	@Column @Pattern(regexp = "[0-9]{10}",message = "Invalid Service Number..!!")
	private String serviceNumber ;
	@Column @Pattern(regexp = "[0-9]{13}",message = "Invalid Sim Number..!!")
	private String simNumber ;
	@Column
	private String simStatus ;
	public SimDetails()
	{
		super();
	}

	@Override
	public String toString() 
	{
		return "SimDetails [simId=" + simId + ", serviceNumber=" + serviceNumber + ", simNumber=" + simNumber
		+ ", simStatus=" + simStatus + "]";
	}

	public int getSimId() {
		return simId;
	}
	public void setSimId(int simId) {
		this.simId = simId;
	}
	public String getServiceNumber() {
		return serviceNumber;
	}
	public void setServiceNumber(String serviceNumber) {
		this.serviceNumber = serviceNumber;
	}
	public String getSimNumber() {
		return simNumber;
	}
	public void setSimNumber(String simNumber) {
		this.simNumber = simNumber;
	}
	public String getSimStatus() {
		return simStatus;
	}
	public void setSimStatus(String simStatus) {
		this.simStatus = simStatus;
	}
	
	public static SimDetailsDTO createSimDetailsDTO(SimDetails objSimDetails)
	{
		SimDetailsDTO objSimDetailsDTO = new SimDetailsDTO();
		
		objSimDetailsDTO.setSimId(objSimDetails.getSimId());
		objSimDetailsDTO.setServiceNumber(objSimDetails.getSimNumber());
		objSimDetailsDTO.setSimNumber(objSimDetails.getSimNumber());
		objSimDetailsDTO.setSimStatus(objSimDetails.getSimStatus());
		
		return objSimDetailsDTO;
	}
	
}









