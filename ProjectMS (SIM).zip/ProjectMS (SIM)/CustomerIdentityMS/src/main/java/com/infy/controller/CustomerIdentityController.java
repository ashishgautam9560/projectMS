package com.infy.controller;

import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infy.advice.Message;
import com.infy.dto.CustomerIdentityDTO;
import com.infy.entity.CustomerIdentity;
import com.infy.service.CustomerIdentityService;

public class CustomerIdentityController
{
	@Autowired
	CustomerIdentityService customerIdentityService;

	
	@PostMapping("/addcustomeridentity")
	public String addcustomeridentity(@Valid @RequestBody CustomerIdentityDTO customerIdentityDTO,Errors errors)
	{
		String response = "";
		if (errors.hasErrors()) {
	
		response = errors.getAllErrors().stream().map(ObjectError::getDefaultMessage)
		.collect(Collectors.joining(","));
		Message error = new Message();
		error.setStatusCode(HttpStatus.NOT_ACCEPTABLE.value());
		error.setMessages(response);
		return "Incorrect Details";
		}
		else
		{
		customerIdentityService.addcustomeridentity(customerIdentityDTO);
		return "Successfully Added Customer Identity";
		}
	}

	@PostMapping("validatecustomeridentity")
	public String validatecustomeridentity(@Valid @RequestBody CustomerIdentityDTO customerIdentityDTO,Errors errors)
	{
		String response = "";
		if (errors.hasErrors())
		{
	
		response = errors.getAllErrors().stream().map(ObjectError::getDefaultMessage)
		.collect(Collectors.joining(","));
		Message error = new Message();
		error.setStatusCode(HttpStatus.NOT_ACCEPTABLE.value());
		error.setMessages(response);
		return "Invalid Details";
		}
		else
		{
			CustomerIdentity customerIdentity=CustomerIdentityDTO.prepareCustomerIdentityEntity(customerIdentityDTO);
			return customerIdentityService.verifycustomeridentity(customerIdentity.getEmailAddress(), customerIdentity.getDateOfBirth());
		}

	}
	@RequestMapping(value = "/getcustomeridentity/{uniqueNumber}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public CustomerIdentityDTO getcustomeridentity(@PathVariable String uniqueNumber)
	{
	return CustomerIdentity.prepareCustomerIdentityDTO(customerIdentityService.getcustomeridentity(uniqueNumber));
	}
}
