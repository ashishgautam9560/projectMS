package com.infy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import com.infy.dto.CustomerIdentityDTO;

@Entity
public class CustomerIdentity 
{
	@Id
	@Column
	private String uniqueNumber;
	@Column
	@NotNull(message = "DateOfBirth value is required")
	@Pattern(regexp="^\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])$",message="Invalid DateOfBirth")
	private String dateOfBirth;
	@Column
	@Length(max=15,message="Firstname should not be more than 15 characters")
	@Pattern(regexp="[a-zA-Z]*",message="Invalid First Name")
	private String firstName;
	@Column
	@Length(max=15,message="\"Lastname should not be more than 15 characters\"")
	@Pattern(regexp="[a-zA-Z]*",message="Invalid Last Name")
	private String lastName;
	@Column
	@NotNull(message = "Email cannot be blank")
	@Pattern(regexp="([a-z]+@[a-z]+\\.[a-z]{2,3})",message="Invalid Email Address")
	private String emailAddress;
	@Column
	private String state;
	public String getUniqueNumber() {
		return uniqueNumber;
	}
	public void setUniqueNumber(String uniqueNumber) {
	this.uniqueNumber = uniqueNumber;
	}
	public String getDateOfBirth() {
	return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
	}
	public String getFirstName() {
	return firstName;
	}
	public void setFirstName(String firstName) {
	this.firstName = firstName;
	}
	public String getLastName() {
	return lastName;
	}
	public void setLastName(String lastName) {
	this.lastName = lastName;
	}
	public String getEmailAddress() {
	return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;
	}
	public String getState() {
	return state;
	}
	public void setState(String state) {
	this.state = state;
	}

	public static CustomerIdentityDTO prepareCustomerIdentityDTO(CustomerIdentity objCustomerIdentity)
	{
	CustomerIdentityDTO objCustomerIdentityDTO = new CustomerIdentityDTO();
	objCustomerIdentityDTO.setUniqueNumber(objCustomerIdentity.getUniqueNumber());
	objCustomerIdentityDTO.setFirstName(objCustomerIdentity.getFirstName());
	objCustomerIdentityDTO.setLastName(objCustomerIdentity.getLastName());
	objCustomerIdentityDTO.setEmailAddress(objCustomerIdentity.getEmailAddress());
	objCustomerIdentityDTO.setDateOfBirth(objCustomerIdentity.getDateOfBirth());
	objCustomerIdentityDTO.setState(objCustomerIdentity.getState());

	return objCustomerIdentityDTO;

	}
}
