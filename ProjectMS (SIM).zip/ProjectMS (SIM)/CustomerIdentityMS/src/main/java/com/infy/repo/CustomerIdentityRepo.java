package com.infy.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infy.entity.CustomerIdentity;

@Repository
public interface CustomerIdentityRepo extends JpaRepository<CustomerIdentity, String>{
	public CustomerIdentity findByEmailandDateOfBirth(String email, String dob);
	public CustomerIdentity findByFnameLname(String fName, String lName);
}
