package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.CustomerIdentityDTO;
import com.infy.entity.CustomerIdentity;
import com.infy.repo.CustomerIdentityRepo;

@Service
public class CustomerIdentityService 
{
	@Autowired
	CustomerIdentityRepo customerIdentityRepo;
	
	public void addcustomeridentity(CustomerIdentityDTO customerIdentityDTO)
	{
		customerIdentityRepo.saveAndFlush(CustomerIdentityDTO.prepareCustomerIdentityEntity(customerIdentityDTO));
	}
	
	public String verifycustomeridentity(String emailAddress , String dateOfBirth)
	{
		CustomerIdentity objCustomerIdentity = customerIdentityRepo.findByEmailandDateOfBirth(emailAddress, dateOfBirth);
		if(objCustomerIdentity==null)
			return "There is no request placed for you";
		else
			return "Email and DOB are validated";
	}

	public String verifycustomerpersonal(String firstName,String lastName , String emailAddress)
	{
		CustomerIdentity objCustomerIdentity = customerIdentityRepo.findByFnameLname(firstName, lastName);
		if(objCustomerIdentity==null)
			return "There is no customer for the provided details";
		else if(objCustomerIdentity.getEmailAddress().equals(emailAddress))
			return "Customer Personal Details Validated";
		else
			return "Invalid email details!!";
	}

	public CustomerIdentity getcustomeridentity(String uniqueNumber)
	{
		return customerIdentityRepo.findById(uniqueNumber).get();
	}
}
