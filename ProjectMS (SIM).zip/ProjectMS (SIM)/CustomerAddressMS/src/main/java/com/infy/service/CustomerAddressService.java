package com.infy.service;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import com.infy.dto.CustomerAddressDTO;
import com.infy.entity.CustomerAddress;
import com.infy.repo.CustomerAddressRepo;

public class CustomerAddressService {

	@Autowired
	CustomerAddressRepo customerAddressRepo;
	
	public void addaddress(@Valid CustomerAddressDTO objCustomerAddressDTO) {
		customerAddressRepo.saveAndFlush(CustomerAddressDTO.prepareAddressEntity(objCustomerAddressDTO));
	}

	public CustomerAddressDTO getaddress(int addressId) {
		Optional<CustomerAddress> customerAddressOptional = customerAddressRepo.findById(addressId);
		return CustomerAddress.prepareAddressDTO(customerAddressOptional.get());
	}

	public void updateAddress(@Valid CustomerAddressDTO objCustomerAddressDTO) {
		customerAddressRepo.saveAndFlush(CustomerAddressDTO.prepareAddressEntity(objCustomerAddressDTO));
	}

}
