//package com.infy.advice;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.bind.annotation.RestControllerAdvice;
//
//@RestControllerAdvice
//public class ExceptionAdvice 
//{
////	// 1) -------------------------------------------------------------------
////	@ExceptionHandler(ConstraintViolationException.class)
////	public ResponseEntity<?> invalidInputFormat(ConstraintViolationException ex) 
////	{
////		Set<ConstraintViolation<?>> violations = ex.getConstraintViolations();
////
////		Message obj = new Message();
////		obj.setStatusCode(HttpStatus.BAD_REQUEST.value());
////		obj.setMessages(ex.getMessage());
////
////		return new ResponseEntity<Message>(obj , HttpStatus.BAD_REQUEST);
////	}
//	
//	
//	
////	// 2) -------------------------------------------------------------------
////	@ExceptionHandler(DetailsNotFoundException.class)
////	public ResponseEntity<?> detailsNotFound(DetailsNotFoundException ex) 
////	{
////		Message obj = new Message();
//////		List<String>  list = new ArrayList<String>();
//////		
//////		list.add(ex.getMessage());
////		
////		obj.setStatusCode(HttpStatus.FORBIDDEN.value());
////		obj.setMessages(ex.getMessage());
//////		obj.setTime(new Date());
////
////		return new ResponseEntity<Message>(obj , HttpStatus.FORBIDDEN);
////	}
//
//	
//	
////	// 3) -------------------------------------------------------------------
////	@ExceptionHandler(SimActivatedException.class)
////	public ResponseEntity<?> simAlreadyActivated(SimActivatedException ex) 
////	{
////		Message res = new Message();
////		
////		res.setStatusCode(HttpStatus.FORBIDDEN.value());
//////		res.setTime(new Date());
////		
//////		List<String> list = new ArrayList<String>();
//////		list.add(ex.getMessage());
////		
////		res.setMessages(ex.getMessage());
////		
////		return new ResponseEntity<Message>(res,HttpStatus.FORBIDDEN) ;
////	}
//
//	
//	
////	// 4) -------------------------------------------------------------------
////	@ExceptionHandler(DateTimeParseException.class)
////	public ResponseEntity<?> timeFomatError(DateTimeParseException ex)
////	{
////		Message obj = new Message();
////		obj.setStatusCode(HttpStatus.BAD_REQUEST.value());
//////		obj.setTime(new Date());
////		
////		List<String> list = new ArrayList<String>();
////		list.add("DOB is not in correct format");
////		
////		obj.setMessages(list);
////		
////		return new ResponseEntity<Message>(obj, HttpStatus.BAD_REQUEST);
////	}
//
//	
//	
//	// 5) -------------------------------------------------------------------
////	@ExceptionHandler(InvalidUserCredentials.class)
////	public ResponseEntity<?> invalidEmailDOB(InvalidUserCredentials ex) 
////	{
////		Message obj = new Message();
////		obj.setStatusCode(HttpStatus.FORBIDDEN.value());
//////		obj.setTime(new Date());
////		
////		List<String> list = new ArrayList<String>();
////		list.add(ex.getMessage());
////		
////		obj.setMessages(list);
////		
////		return new ResponseEntity<Message>(obj, HttpStatus.FORBIDDEN);
////	}
//
//	
//	
////	// 6) -------------------------------------------------------------------
////	@ExceptionHandler(Exception.class)
////	public ResponseEntity<?> throwError(Exception ex) 
////	{
////		Message obj = new Message();
////		obj.setStatusCode(HttpStatus.BAD_REQUEST.value());
//////		obj.setTime(new Date());
//////		
//////		List<String> list = new ArrayList<String>();
//////		list.add("Some of the provided credentials are not valid");
////		
////		obj.setMessages(ex.getMessage());
////		
////		return new ResponseEntity<Message>(obj,HttpStatus.BAD_REQUEST);
////	}
//}
