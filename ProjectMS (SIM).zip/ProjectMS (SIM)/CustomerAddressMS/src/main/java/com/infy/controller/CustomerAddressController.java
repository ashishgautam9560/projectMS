package com.infy.controller;

import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infy.advice.Message;
import com.infy.dto.CustomerAddressDTO;
import com.infy.service.CustomerAddressService;

@RestController
@Validated
@RequestMapping("/address")
public class CustomerAddressController 
{
	@Autowired
	CustomerAddressService customerAddressService;
	
	@PostMapping("/insertAddress")
	public String addAddress(@Valid @RequestBody CustomerAddressDTO objCustomerAddressDTO, Errors errors) throws Exception
	{
		String response = "";
		if (errors.hasErrors()) 
		{
			response = errors.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(","));
			Message error = new Message();
			error.setStatusCode(HttpStatus.NOT_ACCEPTABLE.value());
			error.setMessages(response);
			return "Incorrect Details";
		}
		else
		{
			customerAddressService.addaddress(objCustomerAddressDTO);
			return "Added Address Details";
		}
	}
	
	@GetMapping("/getaddress")
	public CustomerAddressDTO getaddress(@RequestParam int addressId)
	{
		return customerAddressService.getaddress(addressId);
	}

	@PutMapping("/updateaddress")
	public String updateaddress(@Valid @RequestBody CustomerAddressDTO objCustomerAddressDTO,Errors errors) throws Exception
	{
		String response = "";
		if (errors.hasErrors()) 
		{
			response = errors.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(","));
			Message error = new Message();
			error.setStatusCode(HttpStatus.NOT_ACCEPTABLE.value());
			error.setMessages(response);
			return "Invalid Address";
		}
		else
		{
			customerAddressService.addaddress(objCustomerAddressDTO);
			return "Updated Address Details";
		}
	}
}










