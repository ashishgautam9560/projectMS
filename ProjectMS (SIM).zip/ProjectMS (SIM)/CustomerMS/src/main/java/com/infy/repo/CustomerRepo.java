package com.infy.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infy.entity.Customer;

//@Repository
public interface CustomerRepo extends JpaRepository<Customer, String>
{
	
}