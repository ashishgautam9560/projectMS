package com.infy.dto;

import org.hibernate.validator.constraints.Length;

import com.infy.entity.Customer;

public class CustomerDTO
{
	@Length(min=16,max=16,message="Id should be 16 digit")
	private String uniqueNumber;

	private String dateOfBirth;

	private String emailAddress;

	private String firstName;

	private String lastName;

	private String idType;

	private String state;

	private int simId;
	private int addressId;

	public int getSimId() {
		return simId;
	}
	public void setSimId(int simId) {
		this.simId = simId;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getUniqueNumber() {
	return uniqueNumber;
	}
	public void setUniqueNumber(String uniqueNumber) {
		this.uniqueNumber = uniqueNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getIdType() {
		return idType;
	}
	public void setIdType(String idType) {
		this.idType = idType;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public static Customer prepareCustomerEntity(CustomerDTO objCustomerDTO)
	{
		Customer objCustomer = new Customer();
		objCustomer.setUniqueNumber(objCustomerDTO.getUniqueNumber());
		objCustomer.setDateOfBirth(objCustomerDTO.getDateOfBirth());
		objCustomer.setEmailAddress(objCustomerDTO.getEmailAddress());
		objCustomer.setFirstName(objCustomerDTO.getFirstName());
		objCustomer.setLastName(objCustomerDTO.getLastName());
		objCustomer.setState(objCustomerDTO.getState());
		objCustomer.setIdType(objCustomerDTO.getIdType());
		objCustomer.setSimId(objCustomerDTO.getSimId());
		objCustomer.setAddressId(objCustomerDTO.getAddressId());
		return objCustomer;

	}
}
