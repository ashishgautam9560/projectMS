package com.infy.dto;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

public class CustomerAddressDTO
{
	private int addressId;
	@Length(max=25, message = "Error: The maximum length of address can be 25 characters..!!")
	private String address;
	@Pattern(regexp="[a-zA-Z ]+",message= "Invalid City..!!")
	private String city;
	@Length(min=6,max=6, message = "Invalid Pincode..!!")
	private String pincode;
	@Pattern(regexp="[a-zA-Z ]+",message= "Invalid State..!!")
	private String state;
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}	
	
	@Override
	public String toString() {
		return "AddressDTO [addressId=" + addressId + ", address=" + address + ", city=" + city + ", pincode=" + pincode
				+ ", state=" + state + "]";
	}
}
