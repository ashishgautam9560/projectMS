package com.infy.exception;

public class SimActivatedException extends Exception
{
	// 1)
	private static final long serialVersionUID = 1207226409778147294L;

	// 2) default
	public SimActivatedException() {}

	// 3) parameterized
	public SimActivatedException(String str) 
	{
		super(str);
	}

}
