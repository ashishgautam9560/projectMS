package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.dto.CustomerDTO;
import com.infy.entity.Customer;
import com.infy.repo.CustomerRepo;

@Service
public class CustomerService 
{
	@Autowired
	CustomerRepo customerRepo;
	
	public void addcustomer(CustomerDTO customerDTO)
	{
		customerRepo.saveAndFlush(CustomerDTO.prepareCustomerEntity(customerDTO));
	}
	public CustomerDTO getcustomer(String uniqueNumber)
	{
		return Customer.prepareCustomerDTO(customerRepo.findById(uniqueNumber).get());
	}
}
