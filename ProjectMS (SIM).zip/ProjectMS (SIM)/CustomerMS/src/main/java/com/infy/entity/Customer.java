package com.infy.entity;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import org.hibernate.validator.constraints.Length;

import com.infy.dto.CustomerDTO;

@Entity
public class Customer 
{
	@Id
	@Column
	@Length(min=16,max=16,message="Id should be 16 digit")
	private String uniqueNumber;
	@Column
	private String dateOfBirth;
	@Column
	private String emailAddress;
	@Column
	private String firstName;
	@Column
	private String lastName;
	@Column
	private String idType;
	@Column
	private String state;
	@Column
	private int simId;
	@Column
	private int addressId;

	public int getSimId() {
		return simId;
	}
	public void setSimId(int simId) {
		this.simId = simId;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getUniqueNumber() {
		return uniqueNumber;
	}
	public void setUniqueNumber(String uniqueNumber) {
		this.uniqueNumber = uniqueNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getIdType() {
		return idType;
	}
	public void setIdType(String idType) {
		this.idType = idType;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public static CustomerDTO prepareCustomerDTO(Customer objCustomer)
	{
		CustomerDTO objCustomerDTO = new CustomerDTO();
		objCustomerDTO.setUniqueNumber(objCustomer.getUniqueNumber());
		objCustomerDTO.setDateOfBirth(objCustomer.getDateOfBirth());
		objCustomerDTO.setEmailAddress(objCustomer.getEmailAddress());
		objCustomerDTO.setFirstName(objCustomer.getFirstName());
		objCustomerDTO.setLastName(objCustomer.getLastName());
		objCustomerDTO.setIdType(objCustomer.getIdType());
		objCustomerDTO.setState(objCustomer.getState());
		objCustomerDTO.setSimId(objCustomer.getSimId());
		objCustomerDTO.setAddressId(objCustomer.getAddressId());

	return objCustomerDTO;

	}
}
