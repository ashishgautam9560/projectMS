package com.infy.exception;

public class InvalidUserCredentials extends Exception
{
	// 1) 
	private static final long serialVersionUID = -6944390756869696599L;

	// 2) default
	public InvalidUserCredentials() {}

	// 3) parameterized
	public InvalidUserCredentials(String str) 
	{
		super(str);
	}
}
