package com.infy.controller;

import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infy.advice.Message;
import com.infy.dto.CustomerDTO;
import com.infy.dto.CustomerIdentityDTO;
import com.infy.exception.InvalidUserCredentials;
import com.infy.service.CustomerService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@Validated
@CrossOrigin
public class CustomerController 
{
	@Autowired
	CustomerService customerService;
	
	@Autowired
	RestTemplate template;
	
	@HystrixCommand(fallbackMethod="addcustomerFallback")
	@PostMapping(value = "/addcustomer" , produces = MediaType.APPLICATION_JSON_VALUE)
	public String addcustomer(@Valid  @RequestBody CustomerDTO customerDTO,Errors errors) throws InvalidUserCredentials
	{

		String response = "";
		if (errors.hasErrors()) 
		{
			response = errors.getAllErrors().stream().map(ObjectError::getDefaultMessage)
			.collect(Collectors.joining(","));
			Message error = new Message();
			error.setStatusCode(HttpStatus.NOT_ACCEPTABLE.value());
			error.setMessages(response);
			return "Invalid Details";
		}
		else
		{
			//String status;
			CustomerIdentityDTO objCustomerIdentityDTO = template.getForObject("http://CUSTOMERIDENTITYMS"+"/customeridentity/getcustomeridentity/"+customerDTO.getUniqueNumber(), CustomerIdentityDTO.class);
			if(objCustomerIdentityDTO.getFirstName().equals(customerDTO.getFirstName()) && objCustomerIdentityDTO.getLastName().equals(customerDTO.getLastName()))
			{
				if(objCustomerIdentityDTO.getDateOfBirth().equals(customerDTO.getDateOfBirth()))
					template.execute("http://SIMDETAILSMS"+"/simdetails/setsimstatus/"+customerDTO.getSimId(), HttpMethod.PUT, null, null);
				else
					return "DOB is not correct..!!";
			}
			else
				return "Incorrect Name..!!";
			customerService.addcustomer(customerDTO);
			return "Customer is added successfully.";
		}
	}

	public String addcustomerFallback(@Valid  @RequestBody CustomerDTO customerDTO,Errors errors)
	{
		return "In Fallback Service Not Working";
	}

	@GetMapping("/getcustomer")
	public CustomerDTO getcustomer(@RequestParam String uniqueNumber)
	{
		return customerService.getcustomer(uniqueNumber);
	}

}
