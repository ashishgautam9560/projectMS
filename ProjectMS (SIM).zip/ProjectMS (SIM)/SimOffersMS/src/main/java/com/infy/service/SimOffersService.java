package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.SimOffersDTO;
import com.infy.entity.SimOffers;
import com.infy.repo.SimOffersRepo;

@Service
public class SimOffersService 
{
	@Autowired
	SimOffersRepo simOffersRepo;
	
	public void addSimOffer(SimOffers simOffers){
		simOffersRepo.save(simOffers);
	}
	
	public SimOffersDTO getSimOffer(int simId){
		return SimOffers.prepareSimOffersDTO(simOffersRepo.findBySimId(simId));
	}
}







