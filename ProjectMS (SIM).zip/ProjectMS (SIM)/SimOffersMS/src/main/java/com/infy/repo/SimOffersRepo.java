package com.infy.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infy.entity.SimOffers;

@Repository
public interface SimOffersRepo extends JpaRepository<SimOffers, Integer>
{
	public SimOffers findBySimId(int simId);
}
