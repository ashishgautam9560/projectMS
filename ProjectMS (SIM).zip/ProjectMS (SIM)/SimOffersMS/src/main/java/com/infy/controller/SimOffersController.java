package com.infy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infy.dto.SimOffersDTO;
import com.infy.service.SimOffersService;

@RestController
@Validated
public class SimOffersController 
{
	@Autowired
	SimOffersService simOffersService;
	
	@PostMapping(value = "/addsimoffer/", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> addSimOffer(@RequestBody SimOffersDTO objSimOffersDTO)
	{
		simOffersService.addSimOffer(SimOffersDTO.prepareSimOffersEntity(objSimOffersDTO));
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
	
	@GetMapping(value = "/getsimoffer/", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getSimOffer(@RequestParam("simId") int simId)
	{
		simOffersService.getSimOffer(simId);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}





